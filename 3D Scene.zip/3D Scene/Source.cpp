#include <iostream>         // cout, cerr
#include <cstdlib>          // EXIT_FAILURE
#include <GL/glew.h>        // GLEW library
#include <GLFW/glfw3.h>     // GLFW library

//header files
#define STB_IMAGE_IMPLEMENTATION
#include "stb_image.h"
#include "camera.h"


// GLM Math Header inclusions
#include <glm/glm.hpp>
#include <glm/gtx/transform.hpp>
#include <glm/gtc/type_ptr.hpp>

using namespace std;

//Shader program macro
#ifndef GLSL
#define GLSL(Version, Source) "#version " #Version " core \n" #Source
#endif // !GLSL

namespace
{
	//Window title var
	const char* const WINDOW_TITLE = "3D Scene";

	//Height and width vars
	const int WINDOW_HEIGHT = 600;
	const int WINDOW_WIDTH = 800;

	//GL mesh data
	struct GLMesh {

		GLuint vertexArrayObject;
		GLuint vertexBufferObjects;
		GLuint nVertices; //indices for how the points make the shape

	};
	
	// Texture
	GLuint gTextureId;
	glm::vec2 gUVScale(5.0f, 5.0f);
	GLint gTexWrapMode = GL_REPEAT;

	//Main window
	GLFWwindow* gWindow = nullptr;
	//Triangle Mesh data
	GLMesh gMesh;
	//Shader Program
	GLuint gProgramId;
	GLuint gLampProgramId;
	GLuint gNonTextureProgramId;

	//create camera
	Camera gCamera(glm::vec3(0.0f, 0.0f, 3.0f));

	//Set cursor starting position
	float gLastX = WINDOW_WIDTH / 2.0f;
	float gLastY = WINDOW_HEIGHT / 2.0f;
	bool gFirstMouse = true;

	//time variables for movement that log time between last frame rendered and current frame
	float gDeltaTime = 0.0f;
	float gLastFrameTime = 0.0f;

	
	//Light position and scale
	glm::vec3 gLightPosition(0.0f, 1.0f, 0.0f);
	glm::vec3 gLightScale(2.0f);

	//Plane VBO/VAO
	unsigned int planeVBO, planeVAO;
	float planeVerts;
	
	//Light VAO
	unsigned int lightVBO, lightVAO;
	float lightVerts;

	//coaster & cup
	unsigned int coasterVBO, coasterVAO;
	unsigned int cupVBO, cupVAO;
	float coasterVerts;
	float cupVerts;

	//textures for shapes:
	//Napkin and Holder
	//0 = napkin, 1 = napkin holder
	GLuint uTextureNapkin;
	GLuint uTextureNapkinHolder;
	GLuint uTextureTable;
	GLuint uTextureCoaster;
	GLuint uTextureCup;

	//Light intensity
	float lightIntensity = 1.0;
	float lightHighlightSize = 36.0;
	struct DirLight {
		glm::vec3 position;
		glm::vec3 ambient;
		glm::vec3 diffuse;
		glm::vec3 specular;
	};

	//View modifiers
	bool orthoViewOn = false;

	//Cylinders
	float pi = 3.14159265359;
	

	struct CylinderData {
		GLfloat x;
		GLfloat z;
		GLfloat yStart;
		GLfloat yEnd;
		GLfloat R;
		GLfloat G;
		GLfloat B; 
		GLfloat A;
	}; // struct

	//Unit Circle
	vector<float> unitCircle;

}

//Functions to initialize the program, create and size the window, and render the objects
bool UInitialize(int, char* [], GLFWwindow** window);
void UResizeWindow(GLFWwindow* window, int width, int height);
void UProcessInput(GLFWwindow* window);
void SetVertexAttribPointerShapes();
void UCreateMesh(GLMesh& mesh);
void UDestroyMesh(GLMesh& mesh);
vector<CylinderData> UCreateCylinder(GLfloat height, GLfloat radius);
void UDrawCylinder(glm::mat4 view, glm::mat4 projection);
void URenderPlane();
void URenderLight(glm::mat4 view, glm::mat4 projection);
void URenderCoaster(glm::mat4 view, glm::mat4 projection);
void URenderCup(glm::mat4 view, glm::mat4 projection);
void URender(glm::mat4 projection);
bool UCreateShaderProgram(const char* vertexShaderSource, const char* fragmentShaderSource, GLuint& programId);
void UDestroyShaderProgram(GLuint programId);
bool UCreateTexture(const char* filename, GLuint& textureId);
void UDestroyTexture(GLuint textureId);
void UMousePositionCallback(GLFWwindow* window, double xpos, double ypos);
void UMouseScrollCallback(GLFWwindow*, double xOffset, double yOffset);
void UMouseButtonCallback(GLFWwindow*, int button, int action, int mods);
void UKeyCallback(GLFWwindow*, int key, int scancode, int action, int mods);


/*

VERTEX SHADER SOURCE CODE

*/

const GLchar* vtxShaderSource = GLSL(440,
	layout(location = 0) in vec3 position; // Vertex data from Vertex Attrib Pointer 0
	layout(location = 1) in vec3 normal;
	layout(location = 2) in vec2 textureCoords; //Texture coordinate data

//Outgoing normals, frag positions, texture coordinates
out vec3 vertexNormal;
out vec3 vertexFragmentPos;
out vec2 vertexTextureCoords;

//Global variables for the  transform matrices
uniform mat4 model;
uniform mat4 view;
uniform mat4 projection;

void main()
{
	gl_Position = projection * view * model * vec4(position, 1.0f); // Transforms vertices into clip coordinates
	
	vertexFragmentPos = vec3(model * vec4(position, 1.0f)); // Gets fragment / pixel position in world space only (exclude view and projection)

	vertexNormal = mat3(transpose(inverse(model))) * normal; // get normal vectors in world space only and exclude normal translation properties
	vertexTextureCoords = textureCoords;
	


}
);

/*

FRAGMENT SHADER SOURCE CODE

*/

const GLchar* fragShaderSource = GLSL(440,
	out vec4 fragmentColor;

in vec3 vertexNormal;
in vec3 vertexFragmentPos;
in vec2 vertexTextureCoords;
//Lighting structs

struct DirLight {
	vec3 position;
	vec3 ambient;
	vec3 diffuse;
	vec3 specular;
};

struct PointLight {
	vec3 position;

	float constant;
	float linear;
	float quadratic;

	vec3 ambient;
	vec3 diffuse;
	vec3 specular;
};






uniform vec3 viewPosition;
uniform sampler2D uTexture;
uniform DirLight dirLight;
uniform PointLight pointLight;
uniform float highlightSize;
uniform float specIntensity;
uniform vec3 lightColor;




vec3 CalcDirectionalLight(DirLight light, vec3 normal, vec3 viewDir);
vec3 CalcPointLight(PointLight light, vec3 normal, vec3 fragPos, vec3 viewDir);




void main()
{

	vec3 norm = normalize(vertexNormal);
	vec3 viewDir = normalize(viewPosition - vertexFragmentPos);

	vec3 dirResult = CalcDirectionalLight(dirLight, norm, viewDir);

	vec3 pointResult = CalcPointLight(pointLight, norm, vertexFragmentPos, viewDir);

	vec3 result = dirResult + pointResult;

	fragmentColor = vec4(result, 1.0);

}

vec3 CalcDirectionalLight(DirLight light, vec3 normal, vec3 viewDir) {

	//calculate normal based on light location
	vec3 lightDir = normalize(-light.position);

	//diffuse shading
	float diff = max(dot(normal, lightDir), 0.2);

	//spec shading
	vec3 reflectDir = reflect(-lightDir, normal);

	//Last 0 should be shininess variable
	float spec = pow(max(dot(viewDir, reflectDir), 0.5), highlightSize);

	//combine results
	vec3 ambient = light.ambient * vec3(texture(uTexture, vertexTextureCoords));
	vec3 diffuse = light.diffuse * diff * vec3(texture(uTexture, vertexTextureCoords));
	vec3 specular = light.specular * spec * vec3(texture(uTexture, vertexTextureCoords));


	return (ambient + diffuse + specular);

}

vec3 CalcPointLight(PointLight light, vec3 normal, vec3 fragPos, vec3 viewDir) {
	vec3 lightDir = normalize(light.position - fragPos);

	float diff = max(dot(normal, lightDir), 0.0);

	vec3 reflectDir = reflect(-lightDir, normal);
	//Last 0 should be shininess variable
	float specularComponent = pow(max(dot(viewDir, reflectDir), 0.0), highlightSize);
	vec3 spec = specIntensity * specularComponent * lightColor;

	float distance = length(light.position - fragPos);
	float attenuation = 1.0 / (light.constant + light.linear * distance * light.quadratic * (distance * distance));

	//combine results
	vec3 ambient = light.ambient * vec3(texture(uTexture, vertexTextureCoords));
	vec3 diffuse = light.diffuse * diff * vec3(texture(uTexture, vertexTextureCoords));
	vec3 specular = light.specular * spec * vec3(texture(uTexture, vertexTextureCoords));

	ambient *= attenuation;
	diffuse *= attenuation;
	specular *= attenuation;

	return (ambient + diffuse + specular);


}
);

/*

LIGHTING SHADER SOURCE CODE

*/

const GLchar* lampVertexShaderSource = GLSL(440,

	layout(location = 0) in vec3 position; // VAP position 0 for vertex position data

	//Uniform / Global variables for the  transform matrices
uniform mat4 model;
uniform mat4 view;
uniform mat4 projection;

void main()
{
	gl_Position = projection * view * model * vec4(position, 1.0f); // Transforms vertices into clip coordinates
}
);

/*

LIGHT FRAGMENT SHADER SOURCE CODE

*/

const GLchar * lampFragmentShaderSource = GLSL(440,

	out vec4 fragmentColor; // For outgoing lamp color (smaller cube) to the GPU

void main()
{
	fragmentColor = vec4(0.5f, 1.0f, 0.f, 1.0f); // Set color to white (1.0f,1.0f,1.0f) with alpha 1.0
}
);

// Vertex Shader Source Code for non texured obj
const GLchar* nonTextureVertexShaderSource = GLSL(440,
	// Vertex data from Vertex Attrib Pointer 0
	layout(location = 0) in vec3 position;
// Color data from Vertex Attrib Pointer 1
layout(location = 1) in vec4 color;
// variable to transfer color data to the fragment shader
out vec4 vertexColor;

//Global variables for the  transform matrices (MVC)
uniform mat4 model;
uniform mat4 view;
uniform mat4 projection;

void main()
{
	//MVC to transform vertices to clip coordinates
	gl_Position = projection * view * model * vec4(position, 1.0f);
	// references incoming color data
	vertexColor = color;
}
);


/* Fragment Shader Source Code*/
const GLchar* nonTextureFragmentShaderSource = GLSL(440,
	in vec4 vertexColor; // Variable to hold incoming color data from vertex shader

out vec4 fragmentColor;

void main()
{
	fragmentColor = vec4(vertexColor);
}
);

/*

SHAPES

*/

//Cube vertices
GLfloat napkinCube[] = {
	//Position //normals //textures
	-0.5f, -0.5f, -0.5f, 0.0, -1.0, 0.0,  0.0f, 0.0f,
	0.5f, -0.5f, -0.5f, 0.0, -1.0, 0.0,  1.0f, 0.0f,
	0.5f,  0.5f, -0.5f, 0.0, -1.0, 0.0,  1.0f, 1.0f,
	0.5f,  0.5f, -0.5f, 0.0, -1.0, 0.0,  1.0f, 1.0f,
	-0.5f,  0.5f, -0.5f, 0.0, -1.0, 0.0,  0.0f, 1.0f,
	-0.5f, -0.5f, -0.5f, 0.0, -1.0, 0.0,  0.0f, 0.0f,



	-0.5f,  0.5f,  0.5f, 0.0, 1.0, 0.0,  0.0f, 0.0f,
	-0.5f,  0.5f, -0.5f, 0.0, 1.0, 0.0,  1.0f, 1.0f,
	-0.5f, -0.5f, -0.5f, 0.0, 1.0, 0.0,  0.0f, 1.0f,
	-0.5f, -0.5f, -0.5f, 0.0, 1.0, 0.0,  0.0f, 1.0f,
	-0.5f, -0.5f,  0.5f, 0.0, 1.0, 0.0,  0.0f, 0.0f,
	-0.5f,  0.5f,  0.5f, 0.0, 1.0, 0.0,  1.0f, 0.0f,

	0.5f,  0.5f,  0.5f, 0.0, 0.0, 0.0,  1.0f, 0.0f,
	0.5f,  0.5f, -0.5f, 0.0, 0.0, 0.0,  1.0f, 1.0f,
	0.5f, -0.5f, -0.5f, 0.0, 0.0, 0.0,  0.0f, 1.0f,
	0.5f, -0.5f, -0.5f, 0.0, 1.0, 0.0,  0.0f, 1.0f,
	0.5f, -0.5f,  0.5f, 0.0, 1.0, 0.0,  0.0f, 0.0f,
	0.5f,  0.5f,  0.5f, 0.0, 1.0, 0.0,  1.0f, 0.0f,

	-0.5f, -0.5f, -0.5f, 0.0, 1.0, 0.0,  0.0f, 1.0f,
	0.5f, -0.5f, -0.5f,  0.0, 1.0, 0.0,  1.0f, 1.0f,
	0.5f, -0.5f,  0.5f,  0.0, 1.0, 0.0,  1.0f, 0.0f,
	0.5f, -0.5f,  0.5f,  0.0, 1.0, 0.0,  1.0f, 0.0f,
	-0.5f, -0.5f,  0.5f, 0.0, 1.0, 0.0,  0.0f, 0.0f,
	-0.5f, -0.5f, -0.5f, 0.0, 1.0, 0.0,  0.0f, 1.0f,

	-0.5f,  0.5f, -0.5f, 0.0, 1.0, 0.0,  0.0f, 1.0f,
	0.5f,  0.5f, -0.5f, 0.0, 1.0, 0.0,  1.0f, 1.0f,
	0.5f,  0.5f,  0.5f, 0.0, 1.0, 0.0,  1.0f, 0.0f,
	0.5f,  0.5f,  0.5f, 0.0, 1.0, 0.0,  1.0f, 0.0f,
	-0.5f,  0.5f,  0.5f, 0.0, 1.0, 0.0,  0.0f, 0.0f,
	-0.5f,  0.5f, -0.5f, 0.0, 1.0, 0.0,  0.0f, 1.0f

};

//Table vertices
GLfloat tablePlane[] = {

	-5.0f, -5.0f, -5.0f,	0.0,  1.0, 0.0,		0.0f, 0.0f,
	-5.0f, -5.0f,  5.0f,	0.0,  1.0, 0.0,		0.0f, 1.0f,
	 5.0f, -5.0f,  5.0f,	0.0,  1.0, 0.0,		1.0f, 1.0f,
	 5.0f, -5.0f,  5.0f,	0.0,  1.0, 0.0,		1.0f, 1.0f,
	 5.0f, -5.0f, -5.0f,	0.0,  1.0, 0.0,		1.0f, 0.0f,
	-5.0f, -5.0f, -5.0f,    0.0,  1.0, 0.0,		0.0f, 0.0f

};

GLfloat coaster[] = {
	//Positions				Normals				Tex Coords
	//Small near side
	-0.25f, -0.25f, -0.25f,	1.0f, 0.0f, 0.0f,	0.0f, 0.0f,
	-0.25f,    0.0f, -0.25f,	1.0f, 0.0f, 0.0f,	0.0f, 1.0f,
	 0.25f,	  0.0f, -0.25f,	1.0f, 0.0f, 0.0f,	1.0f, 1.0f,
	 0.25f,	  0.0f, -0.25f,	1.0f, 0.0f, 0.0f,	1.0f, 1.0f,
	 0.25f,	-0.25f, -0.25f,	1.0f, 0.0f, 0.0f,	1.0f, 0.0f,
	-0.25f, -0.25f, -0.25f,	1.0f, 0.0f, 0.0f,	0.0f, 0.0f,

	//Right thin side
	0.25f,	-0.25f, -0.25f,	0.0f, 0.0f, 1.0f,	0.0f, 0.0f,
	0.25f,	  0.0f, -0.25f,	0.0f, 0.0f, 1.0f,	0.0f, 1.0f,
	0.25f,	0.0f,	0.25f,	0.0f, 0.0f, 1.0f,	1.0f, 1.0f,
	0.25f,	0.0f,	0.25f,	0.0f, 0.0f, 1.0f,	1.0f, 1.0f,
	0.25f,	-0.25f,	0.25f,	0.0f, 0.0f, 1.0f,	1.0f, 0.0f,
	0.25f,	-0.25f, -0.25f,	0.0f, 0.0f, 1.0f,	0.0f, 0.0f,

	//Far thin side
	0.25f,	-0.25f,	0.25f,	-1.0f, 0.0f, 0.0f,	0.0f, 0.0f,
	0.25f,	0.0f,	0.25f,	-1.0f, 0.0f, 0.0f,	0.0f, 1.0f,
	-0.25f,    0.0f, 0.25f,	-1.0f, 0.0f, 0.0f,	1.0f, 1.0f,
	-0.25f,    0.0f, 0.25f,	-1.0f, 0.0f, 0.0f,	1.0f, 1.0f,
	-0.25f, -0.25f, 0.25f,	-1.0f, 0.0f, 0.0f,	1.0f, 0.0f,
	0.25f,	-0.25f,	0.25f,	-1.0f, 0.0f, 0.0f,	0.0f, 0.0f,

	//Thin left side
	-0.25f, -0.25f, 0.25f,	0.0f, 0.0f, -1.0f,	0.0f, 0.0f,
	-0.25f, 0.0f, 0.25f,	0.0f, 0.0f, -1.0f,  0.0f, 1.0f,
	-0.25f, 0.0f, -0.25f,	0.0f, 0.0f, -1.0f,  1.0f, 1.0f,
	-0.25f, 0.0f, -0.25f,	0.0f, 0.0f, -1.0f,  1.0f, 1.0f,
	-0.25f, -0.25f, -0.25f,	0.0f, 0.0f, -1.0f,	1.0f, .0f,
	-0.25f, -0.25f, 0.25f,	0.0f, 0.0f, -1.0f,	0.0f, 0.0f,

	//Top
	-0.25f, 0.0f, -0.25f,	0.0f, -1.0f, 0.0f,	0.0f, 0.0f,
	-0.25f, 0.0f, 0.25f,	0.0f, -1.0f, 0.0f,	0.0f, 1.0f,
	0.25f,	0.0f, 0.25f,	0.0f, -1.0f, 0.0f,	1.0f, 1.0f,
	0.25f,	0.0f, 0.25f,	0.0f, -1.0f, 0.0f,	1.0f, 1.0f,
	0.25f,	0.0f, -0.25f,	0.0f, -1.0f, 0.0f,	1.0f, 0.0f,
	-0.25f, 0.0f, -0.25f,	0.0f, -1.0f, 0.0f,	0.0f, 0.0f,

	//Bottom
	-0.25f, -0.25f, -0.25f,	0.0f, 1.0f, 0.0f,	0.0f, 0.0f,
	-0.25f, -0.25f, 0.25f,	0.0f, 1.0f, 0.0f,	0.0f, 1.0f,
	0.25f,	-0.25f,	0.25f,	0.0f, 1.0f, 0.0f,	1.0f, 1.0f,
	0.25f,	-0.25f,	0.25f,	0.0f, 1.0f, 0.0f,	1.0f, 1.0f,
	0.25f,	-0.25f, -0.25f,	0.0f, 1.0f, 0.0f,	1.0f, 0.0f,
	-0.25f, -0.25f, -0.25f,	0.0f, 1.0f, 0.0f,	0.0f, 0.0f

};

GLfloat lightPyramid[] = {
	//Positions            //Normal coords  //Texture Coordinates
	  //Side 1                //Negative Z
	  -0.5f, -0.5f, -0.5f,   0.0f, 0.0f,  -1.0f,   0.0f, 0.0f, //not it
	   0.5f, -0.5f, -0.5f,   0.0f, 0.0f,  -1.0f,   1.0f, 0.0f,
	   0.0f,  0.5f,  0.0f,   0.0f, 0.0f,  -1.0f,   0.5f, 1.0f,
	   //Side 2
	   0.5f, -0.5f, -0.5f,    1.0f, 0.0f, 0.0f,    0.0f, 0.0f,
	   0.5f, -0.5f,  0.5f,    1.0f, 0.0f, 0.0f,    1.0f, 0.0f,
	   0.0f,  0.5f,  0.0f,    1.0f, 0.0f, 0.0f,    0.5f, 1.0f,
	   //Side 3
	   0.5f, -0.5f,  0.5f,    0.0f, 0.0f, 1.0f,    0.0f, 0.0f, //Not it
	  -0.5f, -0.5f,  0.5f,    0.0f, 0.0f, 1.0f,    1.0f, 0.0f,
	   0.0f,  0.5f,  0.0f,    0.0f, 0.0f, 1.0f,    0.5f, 1.0f,
	   //Side 4
	  -0.5f, -0.5f,  0.5f,    -1.0f, 0.0f, 0.0f,    0.0f, 0.0f,
	  -0.5f, -0.5f, -0.5f,    -1.0f, 0.0f, 0.0f,    1.0f, 0.0f,
	   0.0f,  0.5f,  0.0f,    -1.0f, 0.0f, 0.0f,    0.5f, 1.0f,
	   //Base
	  -0.5f, -0.5f, -0.5f,    0.0f, 0.0f, 0.0f,    0.0f, 1.0f,
	   0.5f, -0.5f, -0.5f,    0.0f, 0.0f, 0.0f,    1.0f, 1.0f,
	   0.5f, -0.5f,  0.5f,    0.0f, 0.0f, 0.0f,    1.0f, 0.0f,
	   0.5f, -0.5f,  0.5f,    0.0f, 0.0f, 0.0f,    1.0f, 0.0f,
	  -0.5f, -0.5f,  0.5f,    0.0f, 0.0f, 0.0f,    0.0f, 0.0f,
	  -0.5f, -0.5f, -0.5f,    0.0f, 0.0f, 0.0f,    0.0f, 1.0f
};




// Images are loaded with Y axis going down, but OpenGL's Y axis goes up, so let's flip it
void flipImageVertically(unsigned char* image, int width, int height, int channels)
{
	for (int j = 0; j < height / 2; ++j)
	{
		int index1 = j * width * channels;
		int index2 = (height - 1 - j) * width * channels;

		for (int i = width * channels; i > 0; --i)
		{
			unsigned char tmp = image[index1];
			image[index1] = image[index2];
			image[index2] = tmp;
			++index1;
			++index2;
		}
	}
}


//main program loop
int main(int argc, char* argv[]) {

	//close if initialization fails
	if (!UInitialize(argc, argv, &gWindow))
		return EXIT_FAILURE;

	//Creates mesh and VBO
	UCreateMesh(gMesh);

	//Create Shader Program
	if (!UCreateShaderProgram(vtxShaderSource, fragShaderSource, gProgramId)) {
		return EXIT_FAILURE;
	}
	if (!UCreateShaderProgram(lampVertexShaderSource, lampFragmentShaderSource, gLampProgramId)) {
		return EXIT_FAILURE;
	}
	if (!UCreateShaderProgram(nonTextureVertexShaderSource, nonTextureFragmentShaderSource, gNonTextureProgramId)) {
		return EXIT_FAILURE;
	}

	
	//load texture file names
	const char* napkinTextureFileName = "../napkins_Texture.jpg";
	const char* napkinHolderTextureFileName = "../napkin_holder_texture.jpg";
	const char* tableTextureFileName = "../wood_texture.jpg";
	const char* coasterTextureFileName = "../Floral.jpg";
	const char* cupTextureFile = "../cup.jpg";
	
	//load textures
	if (!UCreateTexture(napkinTextureFileName, uTextureNapkin)) {
		cout << "Failed loading texture " << uTextureNapkin << endl;
		return EXIT_FAILURE;
	}

	if (!UCreateTexture(napkinHolderTextureFileName, uTextureNapkinHolder)) {
		cout << "Failed loading texture " << uTextureNapkinHolder << endl;
		return EXIT_FAILURE;
	}

	if (!UCreateTexture(tableTextureFileName, uTextureTable)) {
		cout << "Failed loading texture " << tableTextureFileName << endl;
		return EXIT_FAILURE;
	}

	if (!UCreateTexture(coasterTextureFileName, uTextureCoaster)) {
		cout << "Failed loading texture " << uTextureCoaster << endl;
		return EXIT_FAILURE;
	}

	if (!UCreateTexture(cupTextureFile, uTextureCup)) {
		cout << "Failed loading texture " << uTextureCup << endl;
		return EXIT_FAILURE;
	}

	//Assim sampler to texture unit
	glUseProgram(gProgramId);

	//Set texture unit numbers
	glUniform1i(glGetUniformLocation(gProgramId, "uTexture"), 0);




	//Set background to black
	glClearColor(0.0f, 0.0f, 0.0f, 1.0f);

	//rendering loop
	while (!glfwWindowShouldClose(gWindow)) {
		glm::mat4 projection;

		if (!orthoViewOn) {
			projection = glm::perspective(glm::radians(gCamera.zoom), (GLfloat)WINDOW_WIDTH / (GLfloat)WINDOW_HEIGHT, 0.1f, 1000.0f);
			orthoViewOn == false;

		}
		else if (orthoViewOn) {
			projection = glm::ortho(-5.0f, 5.0f, -5.0f, 5.0f, 0.1f, 100.0f);
			orthoViewOn == true;
		}


		//Set up frame time tracking
		float currentFrame = glfwGetTime();
		gDeltaTime = currentFrame - gLastFrameTime;
		gLastFrameTime = currentFrame;

		//process input
		UProcessInput(gWindow);

		//Render the frame with correct perspective
		URender(projection);
	
		//Check for pending events
		glfwPollEvents();
	}
	//Release mesh data
	UDestroyMesh(gMesh);

	//Destroy textures
	UDestroyTexture(uTextureNapkin);
	UDestroyTexture(uTextureNapkinHolder);
	UDestroyTexture(uTextureTable);
	//Release shader program
	UDestroyShaderProgram(gProgramId);
	UDestroyShaderProgram(gLampProgramId);

	exit(EXIT_SUCCESS);
}

bool UInitialize(int argc, char* argv[], GLFWwindow** window) {

	//Initialize and configure GL framework (GLFW)
	glfwInit();
	glfwWindowHint(GLFW_CONTEXT_VERSION_MAJOR, 4);
	glfwWindowHint(GLFW_CONTEXT_VERSION_MINOR, 4);
	glfwWindowHint(GLFW_OPENGL_PROFILE, GLFW_OPENGL_CORE_PROFILE);

	//detect iOS
#ifdef __APPLE__
	glfwWindowHint(GLFW_OPENGL_FORWARD_COMPAT, GL_TRUE);
#endif

	//Window creation for GL Framework
	* window = glfwCreateWindow(WINDOW_WIDTH, WINDOW_HEIGHT, WINDOW_TITLE, NULL, NULL);

	//For failed window creation
	if (*window == NULL) {
		std::cout << "GLFW window was not created." << std::endl;
		glfwTerminate();
		return false;
	}
	//Set state to current window parameter
	glfwMakeContextCurrent(*window);
	//Set callback if framebuffer is resized
	glfwSetFramebufferSizeCallback(*window, UResizeWindow);

	//Register mouse cursor position
	glfwSetCursorPosCallback(*window, UMousePositionCallback);
	//Register mouse scroll
	glfwSetScrollCallback(*window, UMouseScrollCallback);
	//Register mouse button
	glfwSetMouseButtonCallback(*window, UMouseButtonCallback);
	//Register view state change key
	glfwSetKeyCallback(*window, UKeyCallback);

	//Hide cursor
	glfwSetInputMode(*window, GLFW_CURSOR, GLFW_CURSOR_DISABLED);

	//Initialize GLEW for version 1.13 and earlier
	glewExperimental = GL_TRUE;
	GLenum GlewInitResult = glewInit();

	//Print error if GLEW doesn't initialize
	if (GLEW_OK != GlewInitResult) {

		std::cerr << glewGetErrorString(GlewInitResult) << std::endl;
		return false;
	}

	//Display GPU OpenGL version number
	cout << "INFO: OpenGL Version: " << glGetString(GL_VERSION) << endl;

	//If successful
	return true;
}

//input processing: GLFW to check whether keys have been pressed/released in this frame and execute action
//Allows program to close when esc is pressed
void UProcessInput(GLFWwindow* window) {

	//Set movement key presses
	//Set W key press -- Move forward
	if (glfwGetKey(window, GLFW_KEY_W) == GLFW_PRESS) {
		gCamera.ProcessKeyboardInput(FORWARD, gDeltaTime);
	}
	//Set A key press -- Strafe Left
	if (glfwGetKey(window, GLFW_KEY_A) == GLFW_PRESS) {
		gCamera.ProcessKeyboardInput(LEFT, gDeltaTime);
	}
	//Set S key press -- Move back
	if (glfwGetKey(window, GLFW_KEY_S) == GLFW_PRESS) {
		gCamera.ProcessKeyboardInput(BACKWARD, gDeltaTime);
	}
	//Set D key press -- Strafe right
	if (glfwGetKey(window, GLFW_KEY_D) == GLFW_PRESS) {
		gCamera.ProcessKeyboardInput(RIGHT, gDeltaTime);
	}
	//Set Q key press -- Yaw up
	if (glfwGetKey(window, GLFW_KEY_Q) == GLFW_PRESS) {
		gCamera.ProcessKeyboardInput(DOWN, gDeltaTime);
	}
	//Set E key press -- Yaw down
	if (glfwGetKey(window, GLFW_KEY_E) == GLFW_PRESS) {
		gCamera.ProcessKeyboardInput(UP, gDeltaTime);
	}
	//Set Esc to quit program
	if (glfwGetKey(window, GLFW_KEY_ESCAPE) == GLFW_PRESS) {
		glfwSetWindowShouldClose(window, true);
	}
	//Switch Projection
	if (glfwGetKey(window, GLFW_KEY_P) == GLFW_PRESS) {
		if (orthoViewOn == true) {
			orthoViewOn = false;
		}
		else {
			orthoViewOn = true;
		}
	}

}

//Callback function executes when window is resized
void UResizeWindow(GLFWwindow* window, int width, int height) {

	glViewport(0, 0, width, height);

}



void URenderPlane() {
	//Set shader
	glUseProgram(gProgramId);

	//Set model 
	glm::mat4 scale = glm::scale(glm::vec3(5.0f, 0.0f, 5.0f));
	glm::mat4 rotation = glm::rotate(45.0f, glm::vec3(0.0f, 5.0f, 0.0f));
	glm::mat4 translation = glm::translate(glm::vec3(0.0f, -5.0f, 5.0f));
	glm::mat4 model = translation * rotation * scale;

	//Set model uniform
	GLint modelLoc = glGetUniformLocation(gProgramId, "model");
	glUniformMatrix4fv(modelLoc, 1, GL_FALSE, glm::value_ptr(model));

	//Bind VAO
	glBindVertexArray(planeVAO);

	//Bind table texture
	glActiveTexture(GL_TEXTURE0);
	glBindTexture(GL_TEXTURE_2D, uTextureTable);

	// Draws the plane
	glDrawArrays(GL_TRIANGLES, 0, planeVerts);
	glBindVertexArray(0);

}

vector<CylinderData> UCreateCylinder(GLfloat height, GLfloat radius) {
	CylinderData cylinder;

	std::vector<CylinderData> cylinderVector; // vector of structs

	//Cylinder with y axis up
	GLfloat cylinderHeight = height, cylinderRadius = radius, cylinderPoints = 360.f;

	for (int i = 0; i < cylinderPoints; ++i)
	{
		GLfloat u = i / (GLfloat)cylinderPoints;


		cylinder.x = cylinderRadius * cos(2 * pi * u);
		cylinder.z = cylinderRadius * sin(2 * pi * u);

		if (i == 0) {
			cylinder.yStart = 0.0;
		}
		else {
			cylinder.yEnd = cylinderHeight;

			cylinderVector.push_back(cylinder);
		}
		cylinder.R = 0.5;
		cylinder.G = 0.75;
		cylinder.B = 0.4;
		cylinder.A = 1.0;

	}

	return cylinderVector;

}

void UDrawCylinder(glm::mat4 view, glm::mat4 projection) {
	//Set model  
	glm::mat4 scale = glm::scale(glm::vec3(2.0f, 0.25f, 2.0f));
	glm::mat4 rotation = glm::rotate(45.0f, glm::vec3(0.0f, 5.0f, 0.0f));
	glm::mat4 translation = glm::translate(glm::vec3(-4.0f, -4.8f, 4.0f));
	glm::mat4 model = translation * rotation * scale;

	//Assign to uniform
	GLint modelLoc = glGetUniformLocation(gNonTextureProgramId, "model");
	glUniformMatrix4fv(modelLoc, 1, GL_FALSE, glm::value_ptr(model));

	//Capture view/projection and set uniform
	GLint viewLoc = glGetUniformLocation(gNonTextureProgramId, "view");
	GLint projLoc = glGetUniformLocation(gNonTextureProgramId, "projection");
	glUniformMatrix4fv(viewLoc, 1, GL_FALSE, glm::value_ptr(view));
	glUniformMatrix4fv(projLoc, 1, GL_FALSE, glm::value_ptr(projection));

	//Bind light VAO
	glBindVertexArray(cupVAO);

	//Bind coaster texture
	glActiveTexture(GL_TEXTURE0);
	glBindTexture(GL_TEXTURE_2D, uTextureCoaster);
	//Draw light object
	glDrawArrays(GL_TRIANGLES, 0, cupVerts);

	//Clear bound VAO
	glBindVertexArray(0);
}

void URenderLight(glm::mat4 view, glm::mat4 projection) {
	//Set lamp shader
	glUseProgram(gLampProgramId);

	//Set model 
	glm::mat4 scale = glm::scale(gLightScale);
	glm::mat4 rotation = glm::rotate(180.0f, glm::vec3(0.0f, 5.0f, 0.0f));
	glm::mat4 translation = glm::translate(gLightPosition);
	glm::mat4 model = translation * rotation * scale;

	//Assign to uniform
	GLint modelLoc = glGetUniformLocation(gLampProgramId, "model");
	glUniformMatrix4fv(modelLoc, 1, GL_FALSE, glm::value_ptr(model));

	//Capture view/projection and set uniform
	glm::mat4 lightView = view;
	glm::mat4 lightProjection = projection;
	GLint viewLoc = glGetUniformLocation(gLampProgramId, "view");
	GLint projLoc = glGetUniformLocation(gLampProgramId, "projection");
	glUniformMatrix4fv(viewLoc, 1, GL_FALSE, glm::value_ptr(lightView));
	glUniformMatrix4fv(projLoc, 1, GL_FALSE, glm::value_ptr(lightProjection));

	//Bind light VAO
	glBindVertexArray(lightVAO);
	glColor3f(1, 0, 0);
	//Draw light object
	glDrawArrays(GL_TRIANGLES, 0, lightVerts);

	//Clear bound VAO
	glBindVertexArray(0);

}
//render coaster
void URenderCoaster(glm::mat4 view, glm::mat4 projection) {
	//Set model  
	glm::mat4 scale = glm::scale(glm::vec3(2.0f, 0.25f, 2.0f));
	glm::mat4 rotation = glm::rotate(45.0f, glm::vec3(0.0f, 5.0f, 0.0f));
	glm::mat4 translation = glm::translate(glm::vec3(3.0f, -4.95f, 4.0f));
	glm::mat4 model = translation * rotation * scale;

	//Assign to uniform
	GLint modelLoc = glGetUniformLocation(gProgramId, "model");
	glUniformMatrix4fv(modelLoc, 1, GL_FALSE, glm::value_ptr(model));

	//Capture view/projection and set uniform
	GLint viewLoc = glGetUniformLocation(gProgramId, "view");
	GLint projLoc = glGetUniformLocation(gProgramId, "projection");
	glUniformMatrix4fv(viewLoc, 1, GL_FALSE, glm::value_ptr(view));
	glUniformMatrix4fv(projLoc, 1, GL_FALSE, glm::value_ptr(projection));

	//Bind light VAO
	glBindVertexArray(coasterVAO);

	//Bind coaster texture
	glActiveTexture(GL_TEXTURE0);
	glBindTexture(GL_TEXTURE_2D, uTextureCoaster);
	//Draw light object
	glDrawArrays(GL_TRIANGLES, 0, coasterVerts);

	//Clear bound VAO
	glBindVertexArray(0);

}

//Render Square Cup
void URenderCup(glm::mat4 view, glm::mat4 projection) {
	//Set model  
	glm::mat4 scale = glm::scale(glm::vec3(1.0f, 7.0f, 1.0f));
	glm::mat4 rotation = glm::rotate(45.0f, glm::vec3(0.0f, 5.0f, 0.0f));
	glm::mat4 translation = glm::translate(glm::vec3(3.0f, -3.2f, 4.0f));
	glm::mat4 model = translation * rotation * scale;

	//Assign to uniform
	GLint modelLoc = glGetUniformLocation(gProgramId, "model");
	glUniformMatrix4fv(modelLoc, 1, GL_FALSE, glm::value_ptr(model));

	//Capture view/projection and set uniform
	GLint viewLoc = glGetUniformLocation(gProgramId, "view");
	GLint projLoc = glGetUniformLocation(gProgramId, "projection");
	glUniformMatrix4fv(viewLoc, 1, GL_FALSE, glm::value_ptr(view));
	glUniformMatrix4fv(projLoc, 1, GL_FALSE, glm::value_ptr(projection));

	//Bind light VAO
	glBindVertexArray(coasterVAO);

	//Bind coaster texture
	glActiveTexture(GL_TEXTURE0);
	glBindTexture(GL_TEXTURE_2D, uTextureCup);
	//Draw light object
	glDrawArrays(GL_TRIANGLES, 0, coasterVerts);

	//Clear bound VAO
	glBindVertexArray(0);

}





//Main render function
void URender(glm::mat4 projection) {

	//Enable z-depth
	glEnable(GL_DEPTH_TEST);

	//Clear frame and z buffers
	glClearColor(0.0f, 0.0f, 0.0f, 1.0f);
	glClear(GL_COLOR_BUFFER_BIT | GL_DEPTH_BUFFER_BIT);

	//identity matrix for transformation
	glm::mat4 transform = glm::mat4(1.0f);

	//Projection matrix --- !!! ADD MULTIPLE PROJECTION OPTIONS !!! ---

	//Set camera position
	glm::mat4 view = gCamera.GetViewMatrix();

	// Set the shader to be used for objects
	glUseProgram(gProgramId);

	//Set model for napkin holder
	glm::mat4 scale = glm::scale(glm::vec3(2.0f, 2.0f, 0.8f));
	glm::mat4 rotation = glm::rotate(180.0f, glm::vec3(0.6f, 0.71f, 0.705f));
	glm::mat4 translation = glm::translate(transform, glm::vec3(0.0f, -4.5f, 0.0f));
	glm::mat4 model = translation * rotation * scale;


	//Pass MVP matrix to the shader
	GLint modelLoc = glGetUniformLocation(gProgramId, "model");
	GLint viewLoc = glGetUniformLocation(gProgramId, "view");
	GLint projLoc = glGetUniformLocation(gProgramId, "projection");

	//Set uniform values
	glUniformMatrix4fv(modelLoc, 1, GL_FALSE, glm::value_ptr(model));
	glUniformMatrix4fv(viewLoc, 1, GL_FALSE, glm::value_ptr(view));
	glUniformMatrix4fv(projLoc, 1, GL_FALSE, glm::value_ptr(projection));

	//Set Dir Light
	DirLight light;
	light.position = glm::vec3(0.0f, 1.0f, 2.0f);
	light.ambient = glm::vec3(0.2f, 0.2f, 0.2f);
	light.diffuse = glm::vec3(0.6f, 0.6f, 0.6f);
	light.specular = glm::vec3(0.4f, 0.4f, 0.4f);

	GLint dirLightPos = glGetUniformLocation(gProgramId, "dirLight.position");
	GLint dirLightAmb = glGetUniformLocation(gProgramId, "dirLight.ambient");
	GLint dirLightDif = glGetUniformLocation(gProgramId, "dirLight.diffuse");
	GLint dirLightSpec = glGetUniformLocation(gProgramId, "dirLight.specular");

	glUniform3f(dirLightPos, light.position.x, light.position.y, light.position.z);
	glUniform3f(dirLightAmb, light.ambient.r, light.ambient.g, light.ambient.b);
	glUniform3f(dirLightDif, light.diffuse.x, light.diffuse.y, light.diffuse.z);
	glUniform3f(dirLightSpec, light.specular.x, light.specular.y, light.specular.z);

	//Set Point Light
	GLint pointLightPos = glGetUniformLocation(gProgramId, "pointLight.position");
	GLint pointLightAmb = glGetUniformLocation(gProgramId, "pointLight.ambient");
	GLint pointLightDif = glGetUniformLocation(gProgramId, "pointLight.diffuse");
	GLint pointLightSpec = glGetUniformLocation(gProgramId, "pointLight.specular");
	GLint pointLightConst = glGetUniformLocation(gProgramId, "pointLight.constant");
	GLint pointLightLin = glGetUniformLocation(gProgramId, "pointLight.linear");
	GLint pointLightQuad = glGetUniformLocation(gProgramId, "pointLight.quadratic");

	glUniform3f(pointLightPos, gLightPosition.x, gLightPosition.y, gLightPosition.z);
	glUniform3f(pointLightAmb, 0.0f, 0.5f, 1.0f);
	glUniform3f(pointLightDif, 1.0f, 0.0f, 0.0f);
	glUniform3f(pointLightSpec, 0.5f, 0.5f, 0.5f);
	glUniform1f(pointLightConst, 1.0f);
	glUniform1f(pointLightLin, 0.09f);
	glUniform1f(pointLightQuad, 0.032f);

	//Light Attributes
	GLint highlightSizeVal = glGetUniformLocation(gProgramId, "highlightSize");
	GLint specIntensityVal = glGetUniformLocation(gProgramId, "specIntensity");
	glUniform1f(highlightSizeVal, lightHighlightSize);
	glUniform1f(specIntensityVal, lightIntensity);



	

	//View Position
	GLint viewPositionLoc = glGetUniformLocation(gProgramId, "viewPosition");
	const glm::vec3 cameraPosition = gCamera.position;
	glUniform3f(viewPositionLoc, cameraPosition.x, cameraPosition.y, cameraPosition.z);
	
	// Activate the vertex buffer object
	glBindVertexArray(gMesh.vertexArrayObject);

	//Bind texture for napkin holder
	glActiveTexture(GL_TEXTURE0);
	glBindTexture(GL_TEXTURE_2D, uTextureNapkinHolder);

	// Draws the napkin holder
	glDrawArrays(GL_TRIANGLES, 0, gMesh.nVertices);
	

	//Set model for napkins
	scale = glm::scale(glm::vec3(1.5f, 1.5f, 0.5f));
	rotation = glm::rotate(180.0f, glm::vec3(-1.8f, -1.72f, 1.7f));
	translation = glm::translate(glm::vec3(0.1f, -4.4f, 0.0f));
	model = translation * rotation * scale;

	//Pass new model matrix to shader
	modelLoc = glGetUniformLocation(gProgramId, "model");
	glUniformMatrix4fv(modelLoc, 1, GL_FALSE, glm::value_ptr(model));

	//Activate the vbo again
	glBindVertexArray(gMesh.vertexArrayObject);

	//Bind napkin holder texture
	glActiveTexture(GL_TEXTURE0);
	glBindTexture(GL_TEXTURE_2D, uTextureNapkin);

	//Draw the napkins
	glDrawArrays(GL_TRIANGLES, 0, gMesh.nVertices);

	//Draw Cup - FIXME
	//UDrawCylinder(view, projection);

	//Render the plane
	URenderPlane();

	//render coaster
	URenderCoaster(view, projection);
	URenderCup(view, projection);
	//Draw Lamp
	URenderLight(view, projection);

	glBindVertexArray(0);
	//Flip back and front buffer per frame
	glfwSwapBuffers(gWindow);
}

//Set vertex attrib pointers for objects using vertex shader
void SetVertexAttribPointerShapes() {
	//Set variables for floats per vertex/normals/texture
	const GLuint floatsPerVertex = 3;
	const GLuint floatsPerNormal = 3;
	const GLuint floatsPerUV = 2;

	//Determine stride between floats in arrays
	GLint stride = sizeof(float) * (floatsPerVertex + floatsPerNormal + floatsPerUV);

	// Create Vertex Attribute Pointers
	glVertexAttribPointer(0, floatsPerVertex, GL_FLOAT, GL_FALSE, stride, 0);
	glEnableVertexAttribArray(0);

	glVertexAttribPointer(1, floatsPerNormal, GL_FLOAT, GL_FALSE, stride, (void*)(sizeof(float) * floatsPerVertex));
	glEnableVertexAttribArray(1);

	glVertexAttribPointer(2, floatsPerUV, GL_FLOAT, GL_FALSE, stride, (void*)(sizeof(float) * (floatsPerVertex + floatsPerNormal)));
	glEnableVertexAttribArray(2);
}

void UCreateMesh(GLMesh& mesh) {

	//Set variables for floats per vertex/normals/texture
	const GLuint floatsPerVertex = 3;
	const GLuint floatsPerNormal = 3;
	const GLuint floatsPerUV = 2;

	//Determine stride between floats in arrays
	GLint stride = sizeof(float) * (floatsPerVertex + floatsPerNormal + floatsPerUV);

	//Generate and bind VAO/VBO for napkin and holder
	glGenVertexArrays(1, &mesh.vertexArrayObject);
	glBindVertexArray(mesh.vertexArrayObject);
	glGenBuffers(1, &mesh.vertexBufferObjects);
	glBindBuffer(GL_ARRAY_BUFFER, mesh.vertexBufferObjects);

	//Sends Napkin/holder data to GPU
	glBufferData(GL_ARRAY_BUFFER, sizeof(napkinCube), napkinCube, GL_STATIC_DRAW);

	//Index counts for napkin/holder
	mesh.nVertices = sizeof(napkinCube) / sizeof(napkinCube[0]);

	//Set and enable attrib pointers for napkin/holder
	SetVertexAttribPointerShapes();

	//Generate and bind VAO/VBO for plane
	glGenVertexArrays(1, &planeVAO);
	glBindVertexArray(planeVAO);
	glGenBuffers(1, &planeVBO);
	glBindBuffer(GL_ARRAY_BUFFER, planeVBO);

	//Send Plane data to GPU
	glBufferData(GL_ARRAY_BUFFER, sizeof(tablePlane), tablePlane, GL_STATIC_DRAW);

	planeVerts = sizeof(tablePlane) / sizeof(tablePlane[0]);

	//Set and enable attrib pointers for plane
	SetVertexAttribPointerShapes();

	//Generate vao/vbo for coaster
	glGenVertexArrays(1, &coasterVAO);
	glBindVertexArray(coasterVAO);
	glGenBuffers(1, &coasterVBO);
	glBindBuffer(GL_ARRAY_BUFFER, coasterVBO);

	//Sends Napkin/holder data to GPU
	glBufferData(GL_ARRAY_BUFFER, sizeof(coaster), coaster, GL_STATIC_DRAW);

	coasterVerts = sizeof(coaster) / sizeof(coaster[0]);

	SetVertexAttribPointerShapes();

	/*
	* 
	* Can't get the cylinder working
	* 
	//Cup data
	vector<CylinderData> cup = UCreateCylinder(5.0f, 1.0f);

	//Generate vao/vbo for coaster
	glGenVertexArrays(1, &cupVAO);
	glBindVertexArray(cupVAO);
	glGenBuffers(1, &cupVBO);
	glBindBuffer(GL_ARRAY_BUFFER, cupVBO);

	//Sends Napkin/holder data to GPU
	glBufferData(GL_ARRAY_BUFFER, cup.size() * sizeof(cup), &cup.front(), GL_STATIC_DRAW);

	cupVerts = sizeof(cup[0])  / sizeof(cup[0].x);

	glVertexAttribPointer(0, 3, GL_FLOAT, GL_FALSE, 7, 0);
	glEnableVertexAttribArray(0);

	glVertexAttribPointer(0, 4, GL_FLOAT, GL_FALSE, 7, 0);
	glEnableVertexAttribArray(1);
	*/

	//Generate and bind VAO/VBO for light object
	glGenVertexArrays(1, &lightVAO);
	glBindVertexArray(lightVAO);
	glGenBuffers(1, &lightVAO);
	glBindBuffer(GL_ARRAY_BUFFER, lightVAO);

	//Send Plane data to GPU
	glBufferData(GL_ARRAY_BUFFER, sizeof(lightPyramid), lightPyramid, GL_STATIC_DRAW);

	lightVerts = sizeof(lightPyramid) / sizeof(lightPyramid[0]);

	//Set and enable attrib pointer for light
	glVertexAttribPointer(0, floatsPerVertex, GL_FLOAT, GL_FALSE, stride, 0);
	glEnableVertexAttribArray(0);
}

//Destroy mesh
void UDestroyMesh(GLMesh& mesh)
{
	glDeleteVertexArrays(1, &mesh.vertexArrayObject);
	glDeleteBuffers(1, &mesh.vertexBufferObjects);
}

bool UCreateShaderProgram(const char* vertexShaderSource, const char* fragmentShaderSource, GLuint& programId) {

	//Compliation and link error reports
	int success = 0;
	char infoLog[512];

	//create shader program
	programId = glCreateProgram();

	//create vertex and frag shader objects
	GLuint vertexShaderId = glCreateShader(GL_VERTEX_SHADER);
	GLuint fragShaderId = glCreateShader(GL_FRAGMENT_SHADER);

	//Retreive Shader src
	glShaderSource(vertexShaderId, 1, &vtxShaderSource, NULL);
	glShaderSource(fragShaderId, 1, &fragShaderSource, NULL);

	//compile vertex shader and check for errors.  If error found, print to log
	glCompileShader(vertexShaderId); //compile vertex shader

	//error check
	glGetShaderiv(vertexShaderId, GL_COMPILE_STATUS, &success);
	//print if errors found
	if (!success) {

		glGetShaderInfoLog(vertexShaderId, 512, NULL, infoLog);
		std::cout << "ERROR: Vertex Shader Compilation Failed \n" << infoLog << std::endl;

		return false;
	}
	//if successful compile fragment shader
	glCompileShader(fragShaderId);
	//Error check and print to log on failure
	glGetShaderiv(fragShaderId, GL_COMPILE_STATUS, &success);

	if (!success) {

		glGetShaderInfoLog(fragShaderId, sizeof(infoLog), NULL, infoLog);
		std::cout << "ERROR: Fragment Shader Compilation Failed \n" << std::endl;

	}

	//Attach the compiled shaders to the shader program
	glAttachShader(programId, vertexShaderId);
	glAttachShader(programId, fragShaderId);

	//Link the shader program
	glLinkProgram(programId);

	//error check on linking
	glGetProgramiv(programId, GL_LINK_STATUS, &success);

	if (!success) {

		glGetProgramInfoLog(programId, sizeof(infoLog), NULL, infoLog);
		std::cout << "ERROR: Shader Program Link Failed \n" << std::endl;

	}

	//If successful, use shader program
	glUseProgram(programId);

	return true;
}

//Destroy shader program function
void UDestroyShaderProgram(GLuint programId) {
	glDeleteProgram(programId);
}

bool UCreateTexture(const char* filename, GLuint& textureId)
{
	int width, height, channels;
	unsigned char* image = stbi_load(filename, &width, &height, &channels, 0);
	if (image)
	{
		flipImageVertically(image, width, height, channels);

		glGenTextures(1, &textureId);
		glBindTexture(GL_TEXTURE_2D, textureId);

		// set the texture wrapping parameters
		glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_WRAP_S, GL_REPEAT);
		glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_WRAP_T, GL_REPEAT);
		// set texture filtering parameters
		glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MIN_FILTER, GL_NEAREST);
		glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MAG_FILTER, GL_NEAREST);

		if (channels == 3)
			glTexImage2D(GL_TEXTURE_2D, 0, GL_RGB8, width, height, 0, GL_RGB, GL_UNSIGNED_BYTE, image);
		else if (channels == 4)
			glTexImage2D(GL_TEXTURE_2D, 0, GL_RGBA8, width, height, 0, GL_RGBA, GL_UNSIGNED_BYTE, image);
		else
		{
			cout << "Not implemented to handle image with " << channels << " channels" << endl;
			return false;
		}

		glGenerateMipmap(GL_TEXTURE_2D);

		stbi_image_free(image);
		glBindTexture(GL_TEXTURE_2D, 0); // Unbind the texture

		return true;
	}

	// Error loading the image
	return false;
}

void UDestroyTexture(GLuint textureId)
{
	glGenTextures(1, &textureId);
}

//Callback runs whenever there is mouse movement
void UMousePositionCallback(GLFWwindow* window, double xpos, double ypos) {
	cout << "Mouse at (" << xpos << ", " << ypos << ")" << endl;

	//Check if this is the first time cursor is captured.  If yes, store cursor position and set boolean to false
	if (gFirstMouse) {
		gLastX = xpos;
		gLastY = ypos;
		gFirstMouse = false;
	}

	//Find current cursor position to move camera to
	float xOffset = xpos - gLastX;
	float yOffset = gLastY - ypos;

	//Store new last values
	gLastX = xpos;
	gLastY = ypos;

	gCamera.ProcessMouseMovement(xOffset, yOffset);
}

//Callback when mouse wheel is scrolled
void UMouseScrollCallback(GLFWwindow*, double xOffset, double yOffset) {
	gCamera.ProcessMouseScroll(yOffset);
	cout << "FOV changed by: " << yOffset << ". Current FOV is " << gCamera.zoom << endl;
	if (gCamera.zoom == 1)
		cout << "FOV cannot go below 1." << endl;
	if (gCamera.zoom == 45)
		cout << "FOV cannot go above 45." << endl;
}

//Callback whenever a mouse button is pressed
void UMouseButtonCallback(GLFWwindow*, int button, int action, int mods) {
	switch (button) {

		//LBM Case
	case GLFW_MOUSE_BUTTON_LEFT:
		if (action == GLFW_PRESS)
			cout << "LMB pressed" << endl;
		else
			cout << "LMB released" << endl;
		//RMB Case
	case GLFW_MOUSE_BUTTON_RIGHT:
		if (action == GLFW_PRESS)
			cout << "RMB pressed" << endl;
		else
			cout << "RMB released" << endl;

		//Middle mouse button case
	case GLFW_MOUSE_BUTTON_MIDDLE:
		if (action == GLFW_PRESS)
			cout << "MMB pressed" << endl;
		else
			cout << "MMB released" << endl;

	}

}

void UKeyCallback(GLFWwindow* window, int key, int scancode, int action, int mods) {
	{
		/*
		if (orthoViewOn)
		orthoViewOn = false;
		else if (!orthoViewOn) {
		orthoViewOn = true;
		*/
	}
}