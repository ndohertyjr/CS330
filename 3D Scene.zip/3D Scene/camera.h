#ifndef CAMERA_H
#define CAMERA_H

//import libraries
#include <glm/glm.hpp>
#include <glm/gtc/matrix_transform.hpp>
#include <vector>

//Define types of camera movement
enum Camera_Movement {
	FORWARD,
	BACKWARD,
	LEFT,
	RIGHT,
	UP,
	DOWN
};

//Set default camera values
const float YAW = -90.0f;
const float PITCH = 0.0f;
const float SPEED = 20.0f;
const float SENSITIVITY = 0.1f;
const float ZOOM = 45.0f;


//Camera class to calculate anlges and movement based on input
class Camera {
public:
	//camera location vertices
	glm::vec3 position;
	glm::vec3 front;
	glm::vec3 up;
	glm::vec3 right;
	glm::vec3 worldUp;

	//Euler angles
	float yaw;
	float pitch;

	//camera customization options
	float movementSpeed;
	float mouseSensitivity;
	float zoom;

	//Constructor with vectors
	Camera(glm::vec3 Position = glm::vec3(0.0f, 0.0f, 0.0f), glm::vec3 Up = glm::vec3(0.0f, 1.0f, 0.0f), float Yaw = YAW, float Pitch = PITCH) : front(glm::vec3(0.0f, 0.0f, -1.0f)), movementSpeed(SPEED), mouseSensitivity(SENSITIVITY), zoom(ZOOM) {

		position = Position;
		worldUp = Up;
		yaw = Yaw;
		pitch = Pitch;
		updateCameraVectors();

	}

	//Contrusctor with individual (scalar) values
	Camera(float posX, float posY, float posZ, float upX, float upY, float upZ, float yaw, float pitch) : front(glm::vec3(0.0f, 0.0f, -1.0f)), movementSpeed(SPEED), mouseSensitivity(SENSITIVITY), zoom(ZOOM) {

		position = glm::vec3(posX, posY, posZ);
		worldUp = glm::vec3(upX, upY, upZ);
		yaw = yaw;
		pitch = pitch;
		updateCameraVectors();
	}

	//returns view matrix with appropriate calculations made
	glm::mat4 GetViewMatrix() {
		return glm::lookAt(position, position + front, up);
	}

	//process keyboard input with abstract values to OS independent
	void ProcessKeyboardInput(Camera_Movement direction, float deltaTime) {

		//calculate velocity based on time it took to render last frame
		float velocity = movementSpeed * deltaTime;

		//Movement based on key pushed
		if (direction == FORWARD)
			position += front * velocity;
		if (direction == BACKWARD)
			position -= front * velocity;
		if (direction == LEFT)
			position -= right * velocity;
		if (direction == RIGHT)
			position += right * velocity;
		if (direction == UP)
			position += up * velocity;
		if (direction == DOWN)
			position -= up * velocity;

	}

	//process mouse input
	void ProcessMouseMovement(float xOffset, float yOffset, GLboolean constrainPitch = true) {

		//set current cursor location
		xOffset *= mouseSensitivity;
		yOffset *= mouseSensitivity;

		yaw += xOffset;
		pitch += yOffset;

		//Set boundaries to avoid screen flips
		if (constrainPitch) {
			if (pitch > 89.0f)
				pitch = 89.0f;
			if (pitch < -89.0)
				pitch = -89.0;
		}

		//update vertices with appropriate angles
		updateCameraVectors();
	}

	//process mouse scrolls
	void ProcessMouseScroll(float yOffset) {
		zoom -= (float)yOffset;
		//Set max and min FOV
		if (zoom < 1.0f)
			zoom = 1.0f;
		if (zoom > 45.0f)
			zoom = 45.0f;
	}

	//Set private function to calculate the matrix multiplication need to update the camera vectors
private:
	void updateCameraVectors() {
		//calculate front vector
		glm::vec3 frontTemp;
		frontTemp.x = cos(glm::radians(yaw)) * cos(glm::radians(pitch));
		frontTemp.y = sin(glm::radians(pitch));
		frontTemp.z = sin(glm::radians(yaw)) * cos(glm::radians(pitch));
		front = glm::normalize(frontTemp);

		//calculate cross product of right and up vectors
		right = glm::normalize(glm::cross(front, worldUp));
		up = glm::normalize(glm::cross(right, front));


	}
};
#endif